PRAKRITI SAPKOTA — PERSONAL WEBSITE

Files:
- index.html: homepage and photo scrapbook gallery
- introduction.html: introduction, education and leadership experience
- style.css: shared pastel styling
- images/achievement-school.jpg
- images/achievement-performance.jpg

PREVIEW:
Open index.html in a web browser. Keep all files and the images folder together.

PUBLISH USING GITHUB PAGES:
1. Open your website repository on GitHub.
2. Click Add file > Upload files.
3. Upload index.html, introduction.html, and style.css.
4. Upload the images folder with both JPG files inside it. If uploading through the browser, you can drag the files from the images folder into the upload area; keep their paths as images/achievement-school.jpg and images/achievement-performance.jpg.
5. Scroll down and click Commit changes. If GitHub asks to replace index.html, confirm the replacement.
6. Open Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch; select branch main and folder /(root), then Save.
8. Wait a minute or two, then open the Pages URL shown there. It will look like https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/.

PRIVACY:
The introduction page currently includes the age and location details provided. Since the site may be public, consider removing the exact address and age before publishing. You can replace the address with just "Chitwan, Nepal" if you prefer.
